exports.PREFIX = "!";
exports.OWNER_ID = "773324771923853312";
exports.Owner_Name = "> ,,Vic''#0001";